package com.mtg.mtgtest.card.client.util;

final class BodyParsingException extends RuntimeException {
    public BodyParsingException(Throwable cause) {
        super(cause);
    }
}
